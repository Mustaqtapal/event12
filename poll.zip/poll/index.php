<!DOCTYPE html>
<html>
<head>
	<title>Online Voting System</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<h1>Hello World How are you today???</h1>
<div class="container">
	<div class="row">
	</div>
<form method="post" action="">
	<div class="row img-thumbnails">
	    <div class="col-md-4 img-thumbnail">
	        <a href="#">
	            <video class="img-thumbnail" width="420" height="240" controls>
  <source src="img/madmen.mp4" type="video/mp4">
</video>
</a><br><br>
<center>
<span class="img-thumbnail" style="padding: 10px 60px 10px 60px;"><input type="radio" name="polling" value="Team1"> &nbsp; <strong>Team1</strong></span>
</center>
	    </div>
	    <div class="col-md-4 img-thumbnail">
	        <a href="#">
	            <img src="#" class="img-thumbnail">
	        </a>
	        <br><br>
<center>
<span class="img-thumbnail" style="padding: 10px 60px 10px 60px;"><input type="radio" name="polling" value="Team2"> &nbsp; <strong>Team2</strong></span>
</center>
	    </div>
	      <div class="col-md-4 img-thumbnail">
	        <a href="#">
	            <img src="#" class="img-thumbnail">
	        </a>
	        <br><br>
<center>
<span class="img-thumbnail" style="padding: 10px 60px 10px 60px;"><input type="radio" name="polling" value="Team3"> &nbsp; <strong>Team3</strong></span>
</center>
	    </div>

	</div><br><br>
<button type="submit" class="btn btn-primary btn-lg pull-right" name="submit"><strong>Vote of your choice</strong></button>
</form>
</div>
</body>
</html>
<?php 
$mus = mysqli_connect('localhost','root','','mustaq');
if (!$mus)
{
	die("Connection Failed:" . mysqli_connect_error());
}

if (isset($_POST['submit']))
{
 $polling = $_POST['polling'];
 $ip = $_SERVER['REMOTE_ADDR'];
if ($polling == '')
  {
  	echo "select atleast one";
  }
  else{
    switch ($polling) {
    	case 'Team1':
    	mysqli_query($mus, "UPDATE poll SET teamf = teamf+1");
    		break;
    	case 'Team2':
    	mysqli_query($mus, "UPDATE poll SET team2 = team2+1");
    		break;
    	case 'Team3':
    	mysqli_query($mus, "UPDATE poll SET team3 = team3+1");
    		break;	
    }
    mysqli_query($mus, "UPDATE poll SET ipaddress = $ip");
    echo "Thanks for voting";
  }
}
?>