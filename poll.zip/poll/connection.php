<?php 

$mus = mysqli_connect('localhost','root','','mustaq');

?>